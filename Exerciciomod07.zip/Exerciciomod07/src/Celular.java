public class Celular {
    //Aqui estão minha propriedades / Variaveis

    public int tamanho;

    public String marca;

    public String modelo;

    //Aqui estão meus metodos usados

    /**
     * @author Rodolfo.Duarte
     *
     * @return retorno inteiro metodo getTamanho
     *
     */
    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return "Iphone 14";
    }

    public void setModelo(String modelo) {
        this.modelo = "Iphone 14";
    }

    public String turnModeloCelular(String modelo) {
        return modelo;
    }

    public float getTamanhoCelular() {
        return 6;
    }
}
