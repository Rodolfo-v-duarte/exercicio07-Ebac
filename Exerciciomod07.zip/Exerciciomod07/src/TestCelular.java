public class TestCelular {

    public static void main(String args[]) {
        Celular celular = new Celular();
        celular.setModelo("Iphone 14");
        System.out.println(celular.modelo);
        celular.setMarca("Apple");
        System.out.println(celular.marca);
        celular.setTamanho(6);
        System.out.println(celular.tamanho);
    }
}